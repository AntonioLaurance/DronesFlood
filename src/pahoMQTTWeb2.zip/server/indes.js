// The ws module is included
const WebSocket = require("ws");

// A server is created
const webSocketServer = new WebSocket.Server({port: 8082});

// Listen to an event where a new client has connected to our server
webSocketServer.on("connection", ws => {
    console.log("New Client connected");
});
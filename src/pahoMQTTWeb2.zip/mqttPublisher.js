//the host to which we want to connect
const host = "20.219.162.228";

//port number the host is listening to
const port = 1884;

//our topic to publish and receive message
const topic = "guest.com/cdfe45dgbhf9/user/all";
//let topic_severity = svr/severity;
//let topic_location = svr/location;
//let topic_info = svr/info;

//variable to hold connection data
let client;

// Function foc connecting
function connect(){
	try{
        
		// create a client instance, 
		// "" is client id, if empty string is passed a random client id will be generated
		client = new Paho.MQTT.Client(host, Number(port), "client_id");

		// will be called when new message arrives
		client.onMessageArrived = onMessage;

		//when connection is lost
		client.onConnectionLost = function(){document.write('Connection lost')};

		// lets connect the client
		client.connect({
			onSuccess : () => {
			    console.log("connected");
			    
				// subscribe to the topic, we will publish message to this topic
				client.subscribe(topic);
			},
			onFailure : () => {
				console.log("failed to connect");
			}
		});
	}
	catch(err){
		console.log(err);
	}
}


function onMessage(mgs){
	//parse the received message
	mgs = JSON.parse(mgs.payloadString);
	let html = document.getElementById('window').innerHTML + `<div>${mgs.m}</div>`;
	//append html to DOM
	document.getElementById('window').innerHTML = html;
}


function publish(){
	//get message form input box
	let m = document.getElementById('message').value;
    
	//prepare the payload
	let data = JSON.stringify({m});
	let mgs = new Paho.MQTT.Message(data);
	mgs.destinationName = topic;
    
	//publish from here
	client.send(mgs);
	
	document.getElementById('message').value = '';
}